# FastAPI application
