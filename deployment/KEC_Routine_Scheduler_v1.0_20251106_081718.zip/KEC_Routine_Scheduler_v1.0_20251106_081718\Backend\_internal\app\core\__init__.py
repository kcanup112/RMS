# Core configuration and utilities
