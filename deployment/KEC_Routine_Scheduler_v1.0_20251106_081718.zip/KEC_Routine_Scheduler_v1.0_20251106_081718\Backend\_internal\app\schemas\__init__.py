# Pydantic schemas for validation
